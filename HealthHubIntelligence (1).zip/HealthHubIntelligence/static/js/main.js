/**
 * Main JavaScript for Health & Fitness App
 */

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize tooltips and popovers
  initTooltipsAndPopovers();
  
  // Initialize food search functionality
  initFoodSearch();
  
  // Initialize notification functionality
  initNotifications();
  
  // Add event listeners for form validations
  initFormValidation();
  
  // Initialize workout tracking
  initWorkoutTracking();
  
  // Initialize any custom charts
  initCustomCharts();
});

/**
 * Initialize Bootstrap tooltips and popovers
 */
function initTooltipsAndPopovers() {
  // Initialize tooltips
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function(tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  
  // Initialize popovers
  const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
  popoverTriggerList.map(function(popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });
}

/**
 * Initialize food search functionality
 */
function initFoodSearch() {
  const foodSearchForm = document.getElementById('foodSearchForm');
  const foodSearchInput = document.getElementById('foodSearchInput');
  const foodSearchResults = document.getElementById('foodSearchResults');
  
  if (!foodSearchForm || !foodSearchInput) return;
  
  foodSearchForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const searchQuery = foodSearchInput.value.trim();
    if (searchQuery.length < 2) return;
    
    // Show loading state
    foodSearchResults.innerHTML = '<div class="text-center p-3"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
    
    // Fetch food data from API
    fetch(`/api/search-food?query=${encodeURIComponent(searchQuery)}`)
      .then(response => response.json())
      .then(data => {
        displayFoodSearchResults(data, foodSearchResults);
      })
      .catch(error => {
        console.error('Error fetching food data:', error);
        foodSearchResults.innerHTML = '<div class="alert alert-danger">Error fetching food data. Please try again.</div>';
      });
  });
}

/**
 * Display food search results
 */
function displayFoodSearchResults(data, resultContainer) {
  if (!data.found) {
    resultContainer.innerHTML = `<div class="alert alert-warning">No nutrition data found for "${data.food}".</div>`;
    return;
  }
  
  const html = `
    <div class="card">
      <div class="card-body">
        <div class="food-item">
          <div class="food-item-header">
            <span class="food-item-name">${data.food}</span>
            <span class="food-item-calories">${data.calories} calories</span>
          </div>
          <div class="food-item-nutrients">
            <div class="food-item-nutrient">
              <span class="food-item-nutrient-value">${data.protein_g}g</span>
              <span class="food-item-nutrient-label">Protein</span>
            </div>
            <div class="food-item-nutrient">
              <span class="food-item-nutrient-value">${data.carbs_g}g</span>
              <span class="food-item-nutrient-label">Carbs</span>
            </div>
            <div class="food-item-nutrient">
              <span class="food-item-nutrient-value">${data.fat_g}g</span>
              <span class="food-item-nutrient-label">Fat</span>
            </div>
            <div class="food-item-nutrient">
              <span class="food-item-nutrient-value">${data.fiber_g}g</span>
              <span class="food-item-nutrient-label">Fiber</span>
            </div>
          </div>
        </div>
        <button type="button" class="btn btn-primary mt-3" onclick="addFoodToMeal('${data.food}', ${data.calories}, ${data.protein_g}, ${data.carbs_g}, ${data.fat_g})">
          Add to meal
        </button>
      </div>
    </div>
  `;
  
  resultContainer.innerHTML = html;
}

/**
 * Add food item to current meal form
 */
function addFoodToMeal(name, calories, protein, carbs, fat) {
  const foodItemsTextarea = document.getElementById('food_items');
  const caloriesInput = document.getElementById('calories');
  const proteinInput = document.getElementById('protein');
  const carbsInput = document.getElementById('carbs');
  const fatInput = document.getElementById('fat');
  
  if (!foodItemsTextarea) return;
  
  // Add food to textarea
  const currentText = foodItemsTextarea.value;
  foodItemsTextarea.value = currentText ? `${currentText}\n${name}` : name;
  
  // Update nutrition inputs if they exist
  if (caloriesInput) {
    const currentCalories = parseInt(caloriesInput.value) || 0;
    caloriesInput.value = currentCalories + calories;
  }
  
  if (proteinInput) {
    const currentProtein = parseFloat(proteinInput.value) || 0;
    proteinInput.value = (currentProtein + protein).toFixed(1);
  }
  
  if (carbsInput) {
    const currentCarbs = parseFloat(carbsInput.value) || 0;
    carbsInput.value = (currentCarbs + carbs).toFixed(1);
  }
  
  if (fatInput) {
    const currentFat = parseFloat(fatInput.value) || 0;
    fatInput.value = (currentFat + fat).toFixed(1);
  }
  
  // Show success message
  const searchResults = document.getElementById('foodSearchResults');
  if (searchResults) {
    searchResults.innerHTML = `<div class="alert alert-success">"${name}" added to your meal.</div>`;
  }
}

/**
 * Initialize notification functionality
 */
function initNotifications() {
  const notificationItems = document.querySelectorAll('.notification-item');
  
  notificationItems.forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = this.getAttribute('data-notification-id');
      if (!notificationId) return;
      
      // Mark notification as read
      fetch(`/api/mark-notification-read/${notificationId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Remove unread styling
          this.classList.remove('unread');
          
          // Update notification counter
          updateNotificationCounter();
        }
      })
      .catch(error => {
        console.error('Error marking notification as read:', error);
      });
    });
  });
}

/**
 * Update notification counter
 */
function updateNotificationCounter() {
  const counter = document.querySelector('.notification-badge .badge');
  if (!counter) return;
  
  const currentCount = parseInt(counter.textContent);
  if (isNaN(currentCount) || currentCount <= 1) {
    counter.style.display = 'none';
  } else {
    counter.textContent = currentCount - 1;
  }
}

/**
 * Initialize form validation
 */
function initFormValidation() {
  const forms = document.querySelectorAll('.needs-validation');
  
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      
      form.classList.add('was-validated');
    }, false);
  });
}

/**
 * Initialize workout tracking functionality
 */
function initWorkoutTracking() {
  const exerciseTypeInput = document.getElementById('exercise_type');
  const intensitySelect = document.getElementById('intensity');
  const durationInput = document.getElementById('duration');
  const caloriesBurnedInput = document.getElementById('calories_burned');
  
  if (!exerciseTypeInput || !intensitySelect || !durationInput || !caloriesBurnedInput) return;
  
  // Listen for changes to estimate calories burned
  durationInput.addEventListener('input', estimateCaloriesBurned);
  intensitySelect.addEventListener('change', estimateCaloriesBurned);
  exerciseTypeInput.addEventListener('input', estimateCaloriesBurned);
}

/**
 * Estimate calories burned based on exercise type, duration, and intensity
 */
function estimateCaloriesBurned() {
  const exerciseTypeInput = document.getElementById('exercise_type');
  const intensitySelect = document.getElementById('intensity');
  const durationInput = document.getElementById('duration');
  const caloriesBurnedInput = document.getElementById('calories_burned');
  
  if (!exerciseTypeInput || !intensitySelect || !durationInput || !caloriesBurnedInput) return;
  
  const exerciseType = exerciseTypeInput.value.toLowerCase();
  const intensity = intensitySelect.value;
  const duration = parseInt(durationInput.value) || 0;
  
  if (duration <= 0) {
    caloriesBurnedInput.value = '';
    return;
  }
  
  // Define MET values for different exercises and intensities
  // MET = Metabolic Equivalent of Task
  const metValues = {
    'walking': { 'low': 2.5, 'medium': 3.5, 'high': 4.5 },
    'running': { 'low': 7, 'medium': 9, 'high': 12 },
    'cycling': { 'low': 4, 'medium': 6, 'high': 10 },
    'swimming': { 'low': 5, 'medium': 7, 'high': 10 },
    'weightlifting': { 'low': 3, 'medium': 5, 'high': 6 },
    'yoga': { 'low': 2.5, 'medium': 3, 'high': 4 },
    'hiit': { 'low': 6, 'medium': 8, 'high': 12 },
    'pilates': { 'low': 3, 'medium': 4, 'high': 5 },
    'dancing': { 'low': 3, 'medium': 5, 'high': 7 }
  };
  
  // Default MET values if exercise type not found
  const defaultMet = { 'low': 3, 'medium': 5, 'high': 7 };
  
  // Find appropriate MET value
  let met = defaultMet[intensity];
  for (const [type, values] of Object.entries(metValues)) {
    if (exerciseType.includes(type)) {
      met = values[intensity];
      break;
    }
  }
  
  // Calculate calories burned
  // Formula: calories = MET * weight(kg) * duration(hours)
  // We'll use 70kg as default weight if we don't have user data
  const weight = 70; // Default weight in kg
  const durationHours = duration / 60; // Convert minutes to hours
  const caloriesBurned = Math.round(met * weight * durationHours);
  
  caloriesBurnedInput.value = caloriesBurned;
}

/**
 * Initialize any custom charts on the page
 */
function initCustomCharts() {
  // Check if we're on the diet plan page
  const macroDistributionElement = document.getElementById('macroDistributionChart');
  if (macroDistributionElement) {
    // Get macro values from data attributes or use defaults
    const protein = parseFloat(macroDistributionElement.dataset.protein) || 100;
    const carbs = parseFloat(macroDistributionElement.dataset.carbs) || 200;
    const fat = parseFloat(macroDistributionElement.dataset.fat) || 65;
    
    // Create the chart
    createMacroDistributionChart('macroDistributionChart', protein, carbs, fat);
  }
  
  // Initialize any progress bars with animation
  const progressBars = document.querySelectorAll('[data-progress]');
  progressBars.forEach(bar => {
    const progressValue = parseFloat(bar.dataset.progress) || 0;
    updateProgressBar(bar.id, progressValue);
  });
}

/**
 * Handle liking a post
 */
function likePost(postId) {
  const likeButton = document.querySelector(`#post-${postId} .like-button`);
  const likeCount = document.querySelector(`#post-${postId} .like-count`);
  
  if (!likeButton || !likeCount) return;
  
  // In a real app, this would make an API call to the server
  // For now, we'll just toggle the active state and update the count locally
  
  if (likeButton.classList.contains('active')) {
    // Unlike the post
    likeButton.classList.remove('active');
    likeButton.firstElementChild.classList.remove('text-danger');
    
    let count = parseInt(likeCount.textContent) - 1;
    if (count < 0) count = 0;
    likeCount.textContent = count;
  } else {
    // Like the post
    likeButton.classList.add('active');
    likeButton.firstElementChild.classList.add('text-danger');
    
    const count = parseInt(likeCount.textContent) + 1;
    likeCount.textContent = count;
  }
}
