/**
 * Charts and data visualization for Health & Fitness App
 */

// Create charts when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize charts if the elements exist
  initializeWeightChart();
  initializeNutritionChart();
  initializeWorkoutChart();
  initializeGoalProgressChart();
});

/**
 * Initialize weight tracking chart
 */
function initializeWeightChart() {
  const weightChartElement = document.getElementById('weightChart');
  if (!weightChartElement) return;
  
  // Sample data - in a real app, this would come from the backend
  const dates = getLastNDays(30); // Last 30 days
  const weightData = generateSampleWeightData(dates.length);
  
  const ctx = weightChartElement.getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: dates,
      datasets: [{
        label: 'Weight (kg)',
        data: weightData,
        borderColor: 'rgba(40, 167, 69, 1)',
        backgroundColor: 'rgba(40, 167, 69, 0.1)',
        borderWidth: 2,
        tension: 0.3,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          callbacks: {
            label: function(context) {
              return `Weight: ${context.raw} kg`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          },
          ticks: {
            maxTicksLimit: 10
          }
        },
        y: {
          beginAtZero: false,
          grid: {
            color: 'rgba(200, 200, 200, 0.1)'
          },
          ticks: {
            precision: 1
          }
        }
      }
    }
  });
}

/**
 * Initialize nutrition tracking chart
 */
function initializeNutritionChart() {
  const nutritionChartElement = document.getElementById('nutritionChart');
  if (!nutritionChartElement) return;
  
  // Sample data - in a real app, this would come from the backend
  const dates = getLastNDays(7); // Last 7 days
  const caloriesData = generateRandomData(7, 1800, 2500);
  const proteinData = generateRandomData(7, 80, 120);
  const carbsData = generateRandomData(7, 150, 250);
  const fatData = generateRandomData(7, 50, 80);
  
  const ctx = nutritionChartElement.getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: dates,
      datasets: [{
        label: 'Calories',
        data: caloriesData,
        backgroundColor: 'rgba(40, 167, 69, 0.7)',
        borderColor: 'rgba(40, 167, 69, 1)',
        borderWidth: 1,
        yAxisID: 'y'
      }, {
        label: 'Protein (g)',
        data: proteinData,
        backgroundColor: 'rgba(0, 123, 255, 0.7)',
        borderColor: 'rgba(0, 123, 255, 1)',
        borderWidth: 1,
        yAxisID: 'y1'
      }, {
        label: 'Carbs (g)',
        data: carbsData,
        backgroundColor: 'rgba(255, 193, 7, 0.7)',
        borderColor: 'rgba(255, 193, 7, 1)',
        borderWidth: 1,
        yAxisID: 'y1'
      }, {
        label: 'Fat (g)',
        data: fatData,
        backgroundColor: 'rgba(220, 53, 69, 0.7)',
        borderColor: 'rgba(220, 53, 69, 1)',
        borderWidth: 1,
        yAxisID: 'y1'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'top'
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {
            display: true,
            text: 'Calories'
          },
          grid: {
            color: 'rgba(200, 200, 200, 0.1)'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: 'Grams'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    }
  });
}

/**
 * Initialize workout tracking chart
 */
function initializeWorkoutChart() {
  const workoutChartElement = document.getElementById('workoutChart');
  if (!workoutChartElement) return;
  
  // Sample data - in a real app, this would come from the backend
  const dates = getLastNDays(14); // Last 14 days
  const workoutData = generateRandomData(14, 0, 90, true);
  
  const ctx = workoutChartElement.getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: dates,
      datasets: [{
        label: 'Workout Duration (minutes)',
        data: workoutData,
        backgroundColor: function(context) {
          const value = context.dataset.data[context.dataIndex];
          return value === 0 ? 'rgba(200, 200, 200, 0.2)' : 'rgba(0, 123, 255, 0.7)';
        },
        borderColor: function(context) {
          const value = context.dataset.data[context.dataIndex];
          return value === 0 ? 'rgba(200, 200, 200, 0.5)' : 'rgba(0, 123, 255, 1)';
        },
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const value = context.raw;
              return value === 0 ? 'No workout' : `Duration: ${value} min`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          }
        },
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Minutes'
          },
          grid: {
            color: 'rgba(200, 200, 200, 0.1)'
          }
        }
      }
    }
  });
}

/**
 * Initialize goal progress chart
 */
function initializeGoalProgressChart() {
  const goalProgressElement = document.getElementById('goalProgressChart');
  if (!goalProgressElement) return;
  
  // Sample data - in a real app, this would come from the backend
  const goals = ['Weight Loss', 'Daily Steps', 'Protein Intake', 'Workout Frequency'];
  const progress = [75, 90, 60, 80]; // Percentage values
  
  const ctx = goalProgressElement.getContext('2d');
  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: goals,
      datasets: [{
        label: 'Current Progress',
        data: progress,
        backgroundColor: 'rgba(40, 167, 69, 0.2)',
        borderColor: 'rgba(40, 167, 69, 1)',
        borderWidth: 2,
        pointBackgroundColor: 'rgba(40, 167, 69, 1)',
        pointRadius: 4
      }, {
        label: 'Target',
        data: [100, 100, 100, 100],
        backgroundColor: 'rgba(0, 0, 0, 0)',
        borderColor: 'rgba(200, 200, 200, 0.5)',
        borderWidth: 1,
        borderDash: [5, 5],
        pointRadius: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom'
        }
      },
      scales: {
        r: {
          angleLines: {
            color: 'rgba(200, 200, 200, 0.2)'
          },
          grid: {
            color: 'rgba(200, 200, 200, 0.2)'
          },
          suggestedMin: 0,
          suggestedMax: 100,
          ticks: {
            stepSize: 25,
            callback: function(value) {
              return value + '%';
            }
          },
          pointLabels: {
            font: {
              weight: 'bold'
            }
          }
        }
      }
    }
  });
}

/**
 * Generate an array of the last N days in the format "MMM DD"
 */
function getLastNDays(n) {
  const dates = [];
  for (let i = n - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    dates.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
  }
  return dates;
}

/**
 * Generate sample weight data with a slight downward trend
 */
function generateSampleWeightData(numDays) {
  const startWeight = 75 + Math.random() * 5;
  const data = [];
  
  for (let i = 0; i < numDays; i++) {
    // Generate weight with slight downward trend and small fluctuations
    const trend = -0.05 * i; // Slight downward trend
    const fluctuation = (Math.random() - 0.5) * 0.4; // Small daily fluctuations
    const weight = startWeight + trend + fluctuation;
    data.push(weight.toFixed(1));
  }
  
  return data;
}

/**
 * Generate random data within a range
 */
function generateRandomData(count, min, max, allowZeros = false) {
  const data = [];
  for (let i = 0; i < count; i++) {
    if (allowZeros && Math.random() < 0.2) {
      // 20% chance of zero (e.g., for rest days in workout chart)
      data.push(0);
    } else {
      const value = min + Math.random() * (max - min);
      data.push(Math.round(value));
    }
  }
  return data;
}

/**
 * Create a doughnut chart for macro distribution
 */
function createMacroDistributionChart(elementId, protein, carbs, fat) {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  const ctx = element.getContext('2d');
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Protein', 'Carbs', 'Fat'],
      datasets: [{
        data: [protein, carbs, fat],
        backgroundColor: [
          'rgba(0, 123, 255, 0.7)',
          'rgba(255, 193, 7, 0.7)',
          'rgba(220, 53, 69, 0.7)'
        ],
        borderColor: [
          'rgba(0, 123, 255, 1)',
          'rgba(255, 193, 7, 1)',
          'rgba(220, 53, 69, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const value = context.raw;
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = Math.round((value / total) * 100);
              return `${context.label}: ${value}g (${percentage}%)`;
            }
          }
        }
      }
    }
  });
}

/**
 * Update a progress bar with animation
 */
function updateProgressBar(elementId, percentage) {
  const progressBar = document.getElementById(elementId);
  if (!progressBar) return;
  
  // Set initial width
  progressBar.style.width = '0%';
  progressBar.setAttribute('aria-valuenow', 0);
  
  // Determine color based on percentage
  let colorClass = 'bg-success';
  if (percentage < 50) {
    colorClass = 'bg-danger';
  } else if (percentage < 80) {
    colorClass = 'bg-warning';
  }
  
  // Remove existing color classes and add the correct one
  progressBar.className = progressBar.className.replace(/bg-\w+/, '');
  progressBar.classList.add(colorClass);
  
  // Animate the progress bar
  setTimeout(() => {
    progressBar.style.width = `${percentage}%`;
    progressBar.setAttribute('aria-valuenow', percentage);
  }, 50);
}
