from datetime import datetime
from flask_login import UserMixin
from app import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    profile = db.relationship('UserProfile', backref='user', uselist=False)
    meal_logs = db.relationship('MealLog', backref='user', lazy='dynamic')
    workout_logs = db.relationship('WorkoutLog', backref='user', lazy='dynamic')
    posts = db.relationship('Post', backref='user', lazy='dynamic')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic')
    goals = db.relationship('FitnessGoal', backref='user', lazy='dynamic')
    
    def __repr__(self):
        return f'<User {self.username}>'

class UserProfile(db.Model):
    __tablename__ = 'user_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(20))
    height = db.Column(db.Float)  # in cm
    weight = db.Column(db.Float)  # in kg
    activity_level = db.Column(db.String(20))  # sedentary, light, moderate, active, very active
    goal = db.Column(db.String(20))  # weight loss, maintenance, muscle gain
    dietary_preference = db.Column(db.String(50))  # omnivore, vegetarian, vegan, etc.
    medical_conditions = db.Column(db.Text)
    allergies = db.Column(db.Text)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserProfile for User {self.user_id}>'

class MealLog(db.Model):
    __tablename__ = 'meal_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    meal_type = db.Column(db.String(20))  # breakfast, lunch, dinner, snack
    food_items = db.Column(db.Text, nullable=False)
    calories = db.Column(db.Integer)
    protein = db.Column(db.Float)  # in grams
    carbs = db.Column(db.Float)  # in grams
    fat = db.Column(db.Float)  # in grams
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<MealLog {self.meal_type} on {self.date}>'

class WorkoutLog(db.Model):
    __tablename__ = 'workout_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    exercise_type = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.Integer)  # in minutes
    intensity = db.Column(db.String(20))  # low, medium, high
    calories_burned = db.Column(db.Integer)
    notes = db.Column(db.Text)
    date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<WorkoutLog {self.exercise_type} on {self.date}>'

class Post(db.Model):
    __tablename__ = 'posts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    privacy_level = db.Column(db.String(20), default='public')  # public, friends, private
    likes = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Post {self.id} by User {self.user_id}>'

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    notification_type = db.Column(db.String(20))  # reminder, achievement, social
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Notification {self.id} for User {self.user_id}>'

class FitnessGoal(db.Model):
    __tablename__ = 'fitness_goals'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    goal_type = db.Column(db.String(50), nullable=False)  # weight loss, strength, endurance, etc.
    target_value = db.Column(db.Float)  # e.g., target weight in kg
    start_value = db.Column(db.Float)  # e.g., starting weight in kg
    current_value = db.Column(db.Float)  # e.g., current weight in kg
    start_date = db.Column(db.Date, nullable=False)
    target_date = db.Column(db.Date)
    status = db.Column(db.String(20), default='active')  # active, completed, abandoned
    progress = db.Column(db.Float, default=0.0)  # percentage
    
    def __repr__(self):
        return f'<FitnessGoal {self.goal_type} for User {self.user_id}>'
