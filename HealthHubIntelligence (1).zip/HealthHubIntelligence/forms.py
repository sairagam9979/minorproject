from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, BooleanField, SelectField, IntegerField, FloatField, DateField, SubmitField, HiddenField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, NumberRange
from datetime import datetime

class RegistrationForm(FlaskForm):
    """Form for user registration"""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    """Form for user login"""
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class ProfileForm(FlaskForm):
    """Form for user profile"""
    age = IntegerField('Age', validators=[DataRequired(), NumberRange(min=13, max=120)])
    gender = SelectField('Gender', choices=[
        ('male', 'Male'), 
        ('female', 'Female'), 
        ('other', 'Other'),
        ('prefer_not_to_say', 'Prefer not to say')
    ])
    height = FloatField('Height (cm)', validators=[DataRequired(), NumberRange(min=50, max=250)])
    weight = FloatField('Weight (kg)', validators=[DataRequired(), NumberRange(min=20, max=500)])
    activity_level = SelectField('Activity Level', choices=[
        ('sedentary', 'Sedentary (little or no exercise)'),
        ('light', 'Light (light exercise 1-3 days/week)'),
        ('moderate', 'Moderate (moderate exercise 3-5 days/week)'),
        ('active', 'Active (hard exercise 6-7 days/week)'),
        ('very_active', 'Very Active (professional athlete level)')
    ])
    goal = SelectField('Fitness Goal', choices=[
        ('weight_loss', 'Weight Loss'),
        ('maintenance', 'Maintenance'),
        ('muscle_gain', 'Muscle Gain'),
        ('overall_health', 'Overall Health'),
        ('athletic_performance', 'Athletic Performance')
    ])
    dietary_preference = SelectField('Dietary Preference', choices=[
        ('omnivore', 'Omnivore'),
        ('vegetarian', 'Vegetarian'),
        ('vegan', 'Vegan'),
        ('pescatarian', 'Pescatarian'),
        ('keto', 'Keto'),
        ('paleo', 'Paleo'),
        ('gluten_free', 'Gluten Free'),
        ('dairy_free', 'Dairy Free'),
        ('other', 'Other')
    ])
    medical_conditions = TextAreaField('Medical Conditions (if any)', validators=[Optional()])
    allergies = TextAreaField('Food Allergies (if any)', validators=[Optional()])
    submit = SubmitField('Save Profile')

class MealTrackingForm(FlaskForm):
    """Form for tracking meals"""
    meal_type = SelectField('Meal Type', choices=[
        ('breakfast', 'Breakfast'),
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner'),
        ('snack', 'Snack')
    ])
    food_items = TextAreaField('Food Items', validators=[DataRequired()])
    calories = IntegerField('Calories', validators=[Optional(), NumberRange(min=0, max=5000)])
    protein = FloatField('Protein (g)', validators=[Optional(), NumberRange(min=0, max=1000)])
    carbs = FloatField('Carbohydrates (g)', validators=[Optional(), NumberRange(min=0, max=1000)])
    fat = FloatField('Fat (g)', validators=[Optional(), NumberRange(min=0, max=1000)])
    date = DateField('Date', default=datetime.today, validators=[DataRequired()])
    submit = SubmitField('Log Meal')

class WorkoutTrackingForm(FlaskForm):
    """Form for tracking workouts"""
    exercise_type = StringField('Exercise Type', validators=[DataRequired()])
    duration = IntegerField('Duration (minutes)', validators=[DataRequired(), NumberRange(min=1, max=1440)])
    intensity = SelectField('Intensity', choices=[
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High')
    ])
    calories_burned = IntegerField('Calories Burned (estimate)', validators=[Optional(), NumberRange(min=0, max=5000)])
    notes = TextAreaField('Notes', validators=[Optional()])
    date = DateField('Date', default=datetime.today, validators=[DataRequired()])
    submit = SubmitField('Log Workout')

class PostForm(FlaskForm):
    """Form for community posts"""
    content = TextAreaField('Share your progress or thoughts...', validators=[DataRequired(), Length(min=1, max=500)])
    privacy_level = SelectField('Privacy', choices=[
        ('public', 'Public'),
        ('friends', 'Friends Only'),
        ('private', 'Private (only me)')
    ], default='public')
    submit = SubmitField('Post')

class GoalForm(FlaskForm):
    """Form for setting fitness goals"""
    goal_type = SelectField('Goal Type', choices=[
        ('weight_loss', 'Weight Loss'),
        ('weight_gain', 'Weight Gain'),
        ('running_distance', 'Running Distance'),
        ('strength_training', 'Strength Training'),
        ('workout_frequency', 'Workout Frequency'),
        ('water_intake', 'Water Intake'),
        ('other', 'Other')
    ])
    target_value = FloatField('Target Value', validators=[DataRequired()])
    start_value = FloatField('Starting Value', validators=[DataRequired()])
    start_date = DateField('Start Date', default=datetime.today, validators=[DataRequired()])
    target_date = DateField('Target Date', validators=[DataRequired()])
    submit = SubmitField('Set Goal')
