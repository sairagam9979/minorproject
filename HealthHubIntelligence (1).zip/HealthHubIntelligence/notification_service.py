"""
Notification Service Module

This module provides functions for creating and sending notifications to users.
"""
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def create_notification(db, user_id, content, notification_type="reminder"):
    """
    Create a new notification for a user.
    
    Args:
        db: SQLAlchemy database instance
        user_id (int): ID of the user to create notification for
        content (str): Content of the notification
        notification_type (str): Type of notification (reminder, achievement, social)
    
    Returns:
        bool: True if notification was created successfully, False otherwise
    """
    try:
        from models import Notification
        
        notification = Notification(
            user_id=user_id,
            content=content,
            notification_type=notification_type,
            is_read=False,
            created_at=datetime.utcnow()
        )
        
        db.session.add(notification)
        db.session.commit()
        
        logger.info(f"Created notification for user {user_id}: {content}")
        return True
    
    except Exception as e:
        logger.error(f"Error creating notification: {e}")
        return False

def create_reminder_notification(db, user_id, reminder_type, specific_content=None):
    """
    Create a reminder notification with standardized content.
    
    Args:
        db: SQLAlchemy database instance
        user_id (int): ID of the user to create notification for
        reminder_type (str): Type of reminder (meal, workout, water, etc.)
        specific_content (str, optional): Additional specific content for the reminder
    
    Returns:
        bool: True if notification was created successfully, False otherwise
    """
    # Standard reminder messages
    reminder_messages = {
        'meal': "Don't forget to log your meals today!",
        'workout': "Time for your scheduled workout!",
        'water': "Have you had enough water today? Stay hydrated!",
        'sleep': "Getting proper sleep is crucial for recovery. Aim for 7-8 hours tonight.",
        'weekly_checkin': "Time for your weekly check-in. Update your measurements and track your progress!"
    }
    
    # Get standard message based on reminder type
    message = reminder_messages.get(reminder_type, "Reminder from Health & Fitness App")
    
    # Add specific content if provided
    if specific_content:
        message = f"{message} {specific_content}"
    
    return create_notification(db, user_id, message, "reminder")

def create_achievement_notification(db, user_id, achievement_type, achievement_details=None):
    """
    Create an achievement notification with standardized content.
    
    Args:
        db: SQLAlchemy database instance
        user_id (int): ID of the user to create notification for
        achievement_type (str): Type of achievement (streak, milestone, goal_reached, etc.)
        achievement_details (str, optional): Additional details about the achievement
    
    Returns:
        bool: True if notification was created successfully, False otherwise
    """
    # Standard achievement messages
    achievement_messages = {
        'streak': "Great job! You've maintained your logging streak!",
        'workout_milestone': "Fitness milestone reached! Keep up the good work!",
        'weight_goal': "Congratulations! You've reached your weight goal!",
        'nutrition_goal': "You've been meeting your nutrition targets consistently!",
        'first_log': "Congratulations on logging your first entry! Keep it up!"
    }
    
    # Get standard message based on achievement type
    message = achievement_messages.get(achievement_type, "Achievement unlocked!")
    
    # Add specific details if provided
    if achievement_details:
        message = f"{message} {achievement_details}"
    
    return create_notification(db, user_id, message, "achievement")

def create_social_notification(db, user_id, social_type, from_user=None, content=None):
    """
    Create a social interaction notification.
    
    Args:
        db: SQLAlchemy database instance
        user_id (int): ID of the user to create notification for
        social_type (str): Type of social interaction (like, comment, follow, etc.)
        from_user (str, optional): Username of the user who performed the action
        content (str, optional): Additional content related to the interaction
    
    Returns:
        bool: True if notification was created successfully, False otherwise
    """
    # Standard social interaction messages
    social_messages = {
        'like': f"{from_user or 'Someone'} liked your post!",
        'comment': f"{from_user or 'Someone'} commented on your post!",
        'follow': f"{from_user or 'Someone'} is now following you!",
        'mention': f"{from_user or 'Someone'} mentioned you in a post!",
        'share': f"{from_user or 'Someone'} shared your post!"
    }
    
    # Get standard message based on social type
    message = social_messages.get(social_type, f"New social interaction from {from_user or 'someone'}")
    
    # Add specific content if provided
    if content:
        message = f"{message} {content}"
    
    return create_notification(db, user_id, message, "social")

def send_scheduled_notifications(db):
    """
    Send scheduled notifications to all users based on their settings and goals.
    This would be called by a scheduled task (e.g., APScheduler).
    
    Args:
        db: SQLAlchemy database instance
    
    Returns:
        int: Number of notifications sent
    """
    try:
        from models import User, UserProfile
        from datetime import datetime, timedelta
        
        # Get current time information
        now = datetime.utcnow()
        current_hour = now.hour
        day_of_week = now.weekday()  # 0 = Monday, 6 = Sunday
        
        # Counter for notifications sent
        notifications_sent = 0
        
        # Get all active users
        users = User.query.all()
        
        for user in users:
            # Morning reminders (8-10 AM)
            if 8 <= current_hour <= 10:
                create_reminder_notification(db, user.id, 'meal', "Remember to eat a healthy breakfast!")
                notifications_sent += 1
            
            # Midday reminders (12-2 PM)
            elif 12 <= current_hour <= 14:
                create_reminder_notification(db, user.id, 'meal', "Time for a nutritious lunch!")
                notifications_sent += 1
            
            # Evening reminders (6-8 PM)
            elif 18 <= current_hour <= 20:
                create_reminder_notification(db, user.id, 'meal', "Don't forget about dinner!")
                notifications_sent += 1
            
            # Water reminders throughout the day
            if current_hour in [10, 14, 16, 20]:
                create_reminder_notification(db, user.id, 'water')
                notifications_sent += 1
            
            # Weekly check-in reminder (Monday morning)
            if day_of_week == 0 and 8 <= current_hour <= 10:
                create_reminder_notification(db, user.id, 'weekly_checkin')
                notifications_sent += 1
        
        logger.info(f"Sent {notifications_sent} scheduled notifications")
        return notifications_sent
    
    except Exception as e:
        logger.error(f"Error sending scheduled notifications: {e}")
        return 0

def get_unread_notifications_count(user_id):
    """
    Get the count of unread notifications for a user.
    
    Args:
        user_id (int): ID of the user
    
    Returns:
        int: Count of unread notifications
    """
    try:
        from models import Notification
        return Notification.query.filter_by(user_id=user_id, is_read=False).count()
    except Exception as e:
        logger.error(f"Error getting unread notifications count: {e}")
        return 0
