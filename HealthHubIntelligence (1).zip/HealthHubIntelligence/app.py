import os
import logging
from datetime import datetime
from flask import Flask, render_template, redirect, url_for, flash, request, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Create base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the database with the app
db.init_app(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Add template context processor for datetime
@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Import routes after app has been initialized to avoid circular imports
from forms import LoginForm, RegistrationForm, ProfileForm, MealTrackingForm, WorkoutTrackingForm, PostForm
from models import User, UserProfile, MealLog, WorkoutLog, Post, Notification, FitnessGoal
from ml_engine import generate_diet_recommendation, generate_exercise_recommendation
from nutrition_api import search_food
from notification_service import create_notification

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Create database tables within app context
with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def index():
    """Homepage route"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        # Check if user already exists
        existing_user = User.query.filter_by(email=form.email.data).first()
        if existing_user:
            flash('Email already registered', 'danger')
            return render_template('register.html', form=form)
        
        # Create new user
        hashed_password = generate_password_hash(form.password.data)
        new_user = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=hashed_password,
            created_at=datetime.utcnow()
        )
        
        # Add to database
        db.session.add(new_user)
        db.session.commit()
        
        flash('Registration successful! Please complete your profile.', 'success')
        login_user(new_user)
        return redirect(url_for('profile'))
    
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            flash('Login successful!', 'success')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile setup/edit"""
    # Check if user already has a profile
    user_profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    
    form = ProfileForm(obj=user_profile)
    if form.validate_on_submit():
        if not user_profile:
            # Create new profile
            user_profile = UserProfile(user_id=current_user.id)
        
        # Update profile data
        form.populate_obj(user_profile)
        
        # Add to database
        db.session.add(user_profile)
        db.session.commit()
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('profile.html', form=form, user_profile=user_profile)

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    # Get user profile
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    
    if not profile:
        flash('Please complete your profile first.', 'warning')
        return redirect(url_for('profile'))
    
    # Get recent meals and workouts
    recent_meals = MealLog.query.filter_by(user_id=current_user.id).order_by(MealLog.date.desc()).limit(5).all()
    recent_workouts = WorkoutLog.query.filter_by(user_id=current_user.id).order_by(WorkoutLog.date.desc()).limit(5).all()
    
    # Get notifications
    notifications = Notification.query.filter_by(user_id=current_user.id, is_read=False).order_by(Notification.created_at.desc()).limit(5).all()
    
    # Get fitness goals
    goals = FitnessGoal.query.filter_by(user_id=current_user.id).all()
    
    return render_template('dashboard.html', 
                          profile=profile, 
                          recent_meals=recent_meals, 
                          recent_workouts=recent_workouts,
                          notifications=notifications,
                          goals=goals)

@app.route('/track/meal', methods=['GET', 'POST'])
@login_required
def track_meal():
    """Track a meal"""
    form = MealTrackingForm()
    if form.validate_on_submit():
        meal = MealLog(
            user_id=current_user.id,
            meal_type=form.meal_type.data,
            food_items=form.food_items.data,
            calories=form.calories.data,
            protein=form.protein.data,
            carbs=form.carbs.data,
            fat=form.fat.data,
            date=form.date.data
        )
        db.session.add(meal)
        db.session.commit()
        
        flash('Meal logged successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('track_meal.html', form=form, MealLog=MealLog)

@app.route('/track/workout', methods=['GET', 'POST'])
@login_required
def track_workout():
    """Track a workout"""
    form = WorkoutTrackingForm()
    if form.validate_on_submit():
        workout = WorkoutLog(
            user_id=current_user.id,
            exercise_type=form.exercise_type.data,
            duration=form.duration.data,
            intensity=form.intensity.data,
            calories_burned=form.calories_burned.data,
            notes=form.notes.data,
            date=form.date.data
        )
        db.session.add(workout)
        db.session.commit()
        
        flash('Workout logged successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('track_workout.html', form=form, WorkoutLog=WorkoutLog)

@app.route('/diet-plan')
@login_required
def diet_plan():
    """View personalized diet plan"""
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        flash('Please complete your profile first.', 'warning')
        return redirect(url_for('profile'))
    
    # Get recent meals
    recent_meals = MealLog.query.filter_by(user_id=current_user.id).order_by(MealLog.date.desc()).limit(10).all()
    
    # Generate diet recommendations using ML
    recommendations = generate_diet_recommendation(profile, recent_meals)
    
    return render_template('diet_plan.html', profile=profile, recommendations=recommendations)

@app.route('/exercise-plan')
@login_required
def exercise_plan():
    """View personalized exercise plan"""
    profile = UserProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        flash('Please complete your profile first.', 'warning')
        return redirect(url_for('profile'))
    
    # Get recent workouts
    recent_workouts = WorkoutLog.query.filter_by(user_id=current_user.id).order_by(WorkoutLog.date.desc()).limit(10).all()
    
    # Generate exercise recommendations using ML
    recommendations = generate_exercise_recommendation(profile, recent_workouts)
    
    return render_template('exercise_plan.html', profile=profile, recommendations=recommendations)

@app.route('/community', methods=['GET', 'POST'])
@login_required
def community():
    """Community feed and posts"""
    form = PostForm()
    if form.validate_on_submit():
        post = Post(
            user_id=current_user.id,
            content=form.content.data,
            privacy_level=form.privacy_level.data,
            created_at=datetime.utcnow()
        )
        db.session.add(post)
        db.session.commit()
        flash('Post shared successfully!', 'success')
        return redirect(url_for('community'))
    
    # Get community posts based on privacy settings
    posts = Post.query.filter(
        (Post.privacy_level == 'public') | 
        ((Post.privacy_level == 'friends') & (Post.user_id == current_user.id))
    ).order_by(Post.created_at.desc()).all()
    
    return render_template('community.html', form=form, posts=posts)

@app.route('/api/search-food')
@login_required
def api_search_food():
    """API endpoint to search food nutrition info"""
    query = request.args.get('query', '')
    if not query:
        return jsonify({'error': 'No search query provided'}), 400
    
    results = search_food(query)
    return jsonify(results)

@app.route('/api/mark-notification-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    """Mark a notification as read"""
    notification = Notification.query.filter_by(id=notification_id, user_id=current_user.id).first()
    if notification:
        notification.is_read = True
        db.session.commit()
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': 'Notification not found'}), 404

@app.route('/settings')
@login_required
def settings():
    """User settings page"""
    return render_template('settings.html')

@app.route('/notifications/sms-test', methods=['GET', 'POST'])
@login_required
def sms_test():
    """Test SMS notifications"""
    from notification_sms import send_workout_reminder, send_meal_tracking_reminder
    import pprint
    
    result = None
    
    if request.method == 'POST':
        phone_number = request.form.get('phone_number')
        message_type = request.form.get('message_type', 'workout')
        
        if phone_number:
            if message_type == 'workout':
                result = send_workout_reminder(phone_number, current_user.username, 'HIIT')
            else:
                result = send_meal_tracking_reminder(phone_number, current_user.username)
                
            if result and result.get('success'):
                flash('SMS notification sent successfully!', 'success')
            else:
                error_message = result.get('error', 'Unknown error') if result else 'Failed to send SMS'
                flash(f'Failed to send SMS: {error_message}', 'danger')
        else:
            flash('Please enter a phone number', 'warning')
    
    # Add a pretty printer function to the template context
    app.jinja_env.filters['pprint'] = lambda obj: pprint.pformat(obj)
    
    return render_template('sms_test.html', result=result)

@app.errorhandler(404)
def page_not_found(e):
    """404 page not found handler"""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    """500 internal server error handler"""
    return render_template('500.html'), 500
