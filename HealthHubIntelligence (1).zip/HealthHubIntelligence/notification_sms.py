import os
from twilio.rest import Client

# Twilio credentials
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN")
TWILIO_PHONE_NUMBER = os.environ.get("TWILIO_PHONE_NUMBER")


def send_sms_notification(to_phone_number: str, message: str) -> dict:
    """
    Send an SMS notification using Twilio.
    
    Args:
        to_phone_number (str): The recipient's phone number (including country code)
        message (str): The message to send
        
    Returns:
        dict: Result of the operation, including success status and error if any
    """
    # Validate environment variables
    if not all([TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER]):
        return {
            "success": False,
            "error": "Missing Twilio credentials. Check environment variables."
        }
    
    try:
        # Initialize Twilio client
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        # Send the message
        message_obj = client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=to_phone_number
        )
        
        return {
            "success": True,
            "message_sid": message_obj.sid,
            "status": message_obj.status
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def send_workout_reminder(to_phone_number: str, user_name: str, workout_type: str = None) -> dict:
    """
    Send a workout reminder SMS.
    
    Args:
        to_phone_number (str): The recipient's phone number
        user_name (str): The user's name
        workout_type (str, optional): Specific workout type to remind about
        
    Returns:
        dict: Result of the operation
    """
    if workout_type:
        message = f"Hey {user_name}! Don't forget your {workout_type} workout today. Stay consistent with your fitness journey! 💪 - FitLife"
    else:
        message = f"Hey {user_name}! Time for your workout today. Stay consistent with your fitness journey! 💪 - FitLife"
    
    return send_sms_notification(to_phone_number, message)


def send_meal_tracking_reminder(to_phone_number: str, user_name: str) -> dict:
    """
    Send a meal tracking reminder SMS.
    
    Args:
        to_phone_number (str): The recipient's phone number
        user_name (str): The user's name
        
    Returns:
        dict: Result of the operation
    """
    message = f"Hey {user_name}! Don't forget to log your meals today for better nutrition tracking and personalized recommendations. 🥗 - FitLife"
    
    return send_sms_notification(to_phone_number, message)


def send_goal_achievement_notification(to_phone_number: str, user_name: str, achievement: str) -> dict:
    """
    Send a goal achievement notification SMS.
    
    Args:
        to_phone_number (str): The recipient's phone number
        user_name (str): The user's name
        achievement (str): The achievement description
        
    Returns:
        dict: Result of the operation
    """
    message = f"Congratulations {user_name}! 🎉 You've achieved your goal: {achievement}. Keep up the great work! - FitLife"
    
    return send_sms_notification(to_phone_number, message)