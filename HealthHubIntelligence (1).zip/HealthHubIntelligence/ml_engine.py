"""
Machine Learning Engine for Health and Fitness Recommendations
"""
import logging
import numpy as np
from datetime import datetime, timedelta
import random
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Diet recommendation constants
CALORIES_PER_KG = {
    'weight_loss': 20,      # Calories per kg for weight loss
    'maintenance': 30,      # Calories per kg for maintenance
    'muscle_gain': 35,      # Calories per kg for muscle gain
    'overall_health': 30,   # Calories per kg for overall health
    'athletic_performance': 35  # Calories per kg for athletic performance
}

MACRO_RATIOS = {
    'weight_loss': {'protein': 0.40, 'carbs': 0.30, 'fat': 0.30},
    'maintenance': {'protein': 0.30, 'carbs': 0.40, 'fat': 0.30},
    'muscle_gain': {'protein': 0.35, 'carbs': 0.45, 'fat': 0.20},
    'overall_health': {'protein': 0.25, 'carbs': 0.45, 'fat': 0.30},
    'athletic_performance': {'protein': 0.30, 'carbs': 0.50, 'fat': 0.20}
}

# Exercise recommendation constants
EXERCISE_TYPES = {
    'weight_loss': ['Cardio', 'HIIT', 'Circuit Training'],
    'maintenance': ['Mixed Cardio', 'Strength Training', 'Flexibility'],
    'muscle_gain': ['Strength Training', 'Progressive Overload', 'Resistance Training'],
    'overall_health': ['Mixed Cardio', 'Light Strength', 'Yoga', 'Walking'],
    'athletic_performance': ['Sport-Specific', 'Strength', 'Conditioning', 'Agility']
}

DURATION_BY_GOAL = {
    'weight_loss': 45,
    'maintenance': 30,
    'muscle_gain': 60,
    'overall_health': 30,
    'athletic_performance': 60
}

FREQUENCY_BY_GOAL = {
    'weight_loss': 5,
    'maintenance': 3,
    'muscle_gain': 4,
    'overall_health': 3,
    'athletic_performance': 5
}

def calculate_bmr(profile):
    """Calculate Basal Metabolic Rate using Mifflin-St Jeor Equation"""
    try:
        weight = profile.weight  # kg
        height = profile.height  # cm
        age = profile.age
        gender = profile.gender.lower()
        
        if gender == 'male':
            bmr = 10 * weight + 6.25 * height - 5 * age + 5
        else:  # female or other
            bmr = 10 * weight + 6.25 * height - 5 * age - 161
            
        return bmr
    except Exception as e:
        logger.error(f"Error calculating BMR: {e}")
        # Default BMR if calculation fails
        return 1500

def calculate_tdee(profile, bmr=None):
    """Calculate Total Daily Energy Expenditure"""
    if bmr is None:
        bmr = calculate_bmr(profile)
    
    activity_multipliers = {
        'sedentary': 1.2,
        'light': 1.375,
        'moderate': 1.55,
        'active': 1.725,
        'very_active': 1.9
    }
    
    multiplier = activity_multipliers.get(profile.activity_level.lower(), 1.2)
    tdee = bmr * multiplier
    
    return tdee

def calculate_target_calories(profile):
    """Calculate target daily calories based on user goals"""
    tdee = calculate_tdee(profile)
    
    goal_adjustments = {
        'weight_loss': 0.8,      # 20% deficit
        'maintenance': 1.0,      # no adjustment
        'muscle_gain': 1.1,      # 10% surplus
        'overall_health': 1.0,   # no adjustment
        'athletic_performance': 1.15  # 15% surplus
    }
    
    adjustment = goal_adjustments.get(profile.goal.lower(), 1.0)
    target_calories = tdee * adjustment
    
    return round(target_calories)

def calculate_macros(target_calories, goal):
    """Calculate recommended macronutrient breakdown"""
    goal = goal.lower()
    
    # Default to maintenance if goal not found
    macro_ratio = MACRO_RATIOS.get(goal, MACRO_RATIOS['maintenance'])
    
    protein_calories = target_calories * macro_ratio['protein']
    carb_calories = target_calories * macro_ratio['carbs']
    fat_calories = target_calories * macro_ratio['fat']
    
    # Convert calories to grams
    protein_grams = round(protein_calories / 4)  # 4 calories per gram of protein
    carb_grams = round(carb_calories / 4)        # 4 calories per gram of carbs
    fat_grams = round(fat_calories / 9)          # 9 calories per gram of fat
    
    return {
        'protein': protein_grams,
        'carbs': carb_grams,
        'fat': fat_grams
    }

def analyze_meal_history(meals):
    """Analyze user's meal history for patterns and deficiencies"""
    if not meals:
        return {
            'avg_calories': 0,
            'avg_protein': 0,
            'avg_carbs': 0,
            'avg_fat': 0,
            'meal_frequency': 0,
            'common_meals': []
        }
    
    # Group by date to find daily averages
    meal_dates = {}
    for meal in meals:
        date_str = meal.date.strftime('%Y-%m-%d')
        if date_str not in meal_dates:
            meal_dates[date_str] = {
                'calories': 0,
                'protein': 0,
                'carbs': 0,
                'fat': 0,
                'meals': []
            }
        
        meal_dates[date_str]['calories'] += meal.calories or 0
        meal_dates[date_str]['protein'] += meal.protein or 0
        meal_dates[date_str]['carbs'] += meal.carbs or 0
        meal_dates[date_str]['fat'] += meal.fat or 0
        meal_dates[date_str]['meals'].append(meal.meal_type)
    
    # Calculate averages
    total_days = len(meal_dates)
    if total_days == 0:
        return {
            'avg_calories': 0,
            'avg_protein': 0,
            'avg_carbs': 0,
            'avg_fat': 0,
            'meal_frequency': 0,
            'common_meals': []
        }
    
    total_calories = sum(day['calories'] for day in meal_dates.values())
    total_protein = sum(day['protein'] for day in meal_dates.values())
    total_carbs = sum(day['carbs'] for day in meal_dates.values())
    total_fat = sum(day['fat'] for day in meal_dates.values())
    
    # Calculate meal frequency
    all_meals = []
    for day in meal_dates.values():
        all_meals.extend(day['meals'])
    
    from collections import Counter
    meal_counter = Counter(all_meals)
    
    return {
        'avg_calories': round(total_calories / total_days),
        'avg_protein': round(total_protein / total_days, 1),
        'avg_carbs': round(total_carbs / total_days, 1),
        'avg_fat': round(total_fat / total_days, 1),
        'meal_frequency': len(all_meals) / total_days,
        'common_meals': meal_counter.most_common()
    }

def generate_diet_recommendation(profile, meal_history):
    """Generate personalized diet recommendations based on user profile and meal history"""
    try:
        # Calculate target calories and macros
        target_calories = calculate_target_calories(profile)
        macros = calculate_macros(target_calories, profile.goal)
        
        # Analyze meal history
        meal_analysis = analyze_meal_history(meal_history)
        
        # Generate meal recommendations
        meal_plan = generate_meal_plan(profile, target_calories, macros)
        
        # Create the recommendation object
        recommendation = {
            'target_calories': target_calories,
            'target_macros': macros,
            'current_intake': {
                'calories': meal_analysis['avg_calories'],
                'protein': meal_analysis['avg_protein'],
                'carbs': meal_analysis['avg_carbs'],
                'fat': meal_analysis['avg_fat']
            },
            'meal_plan': meal_plan,
            'dietary_tips': generate_dietary_tips(profile, macros, meal_analysis)
        }
        
        return recommendation
    except Exception as e:
        logger.error(f"Error generating diet recommendation: {e}")
        # Return basic recommendation if there's an error
        return {
            'target_calories': 2000,
            'target_macros': {'protein': 100, 'carbs': 200, 'fat': 65},
            'current_intake': {'calories': 0, 'protein': 0, 'carbs': 0, 'fat': 0},
            'meal_plan': {'breakfast': [], 'lunch': [], 'dinner': [], 'snacks': []},
            'dietary_tips': [
                "Aim for a balanced diet with plenty of whole foods.",
                "Stay hydrated by drinking at least 8 glasses of water daily.",
                "Consider consulting with a registered dietitian for personalized advice."
            ]
        }

def generate_meal_plan(profile, target_calories, macros):
    """Generate a simple meal plan based on user preferences and targets"""
    dietary_pref = profile.dietary_preference.lower()
    
    # Simple meal suggestions by dietary preference
    meal_options = {
        'omnivore': {
            'breakfast': [
                'Scrambled eggs with vegetables and whole grain toast',
                'Greek yogurt with berries and granola',
                'Oatmeal with banana and peanut butter'
            ],
            'lunch': [
                'Grilled chicken salad with mixed vegetables',
                'Turkey sandwich on whole grain bread with avocado',
                'Quinoa bowl with roasted vegetables and lean protein'
            ],
            'dinner': [
                'Baked salmon with sweet potato and steamed broccoli',
                'Lean beef stir-fry with brown rice and vegetables',
                'Chicken and vegetable curry with basmati rice'
            ],
            'snacks': [
                'Apple with almond butter',
                'Protein shake with fruit',
                'Handful of mixed nuts',
                'Greek yogurt with honey'
            ]
        },
        'vegetarian': {
            'breakfast': [
                'Scrambled eggs with vegetables and whole grain toast',
                'Greek yogurt with berries and granola',
                'Oatmeal with banana and peanut butter'
            ],
            'lunch': [
                'Chickpea salad with mixed vegetables',
                'Vegetable and cheese sandwich on whole grain bread',
                'Quinoa bowl with roasted vegetables and feta cheese'
            ],
            'dinner': [
                'Lentil curry with basmati rice',
                'Bean and vegetable stir-fry with brown rice',
                'Vegetarian chili with cornbread'
            ],
            'snacks': [
                'Apple with almond butter',
                'Protein shake with fruit',
                'Handful of mixed nuts',
                'Greek yogurt with honey'
            ]
        },
        'vegan': {
            'breakfast': [
                'Tofu scramble with vegetables and whole grain toast',
                'Overnight oats with almond milk and berries',
                'Smoothie bowl with plant-based protein'
            ],
            'lunch': [
                'Chickpea and vegetable salad',
                'Hummus and vegetable wrap on whole grain tortilla',
                'Quinoa bowl with roasted vegetables and tofu'
            ],
            'dinner': [
                'Lentil curry with basmati rice',
                'Bean and vegetable stir-fry with brown rice',
                'Vegetable and bean chili'
            ],
            'snacks': [
                'Apple with almond butter',
                'Plant-based protein shake with fruit',
                'Handful of mixed nuts',
                'Hummus with carrot sticks'
            ]
        }
    }
    
    # Default to omnivore if preference not found
    options = meal_options.get(dietary_pref, meal_options['omnivore'])
    
    # Select random options from each meal type
    import random
    meal_plan = {
        'breakfast': random.sample(options['breakfast'], min(2, len(options['breakfast']))),
        'lunch': random.sample(options['lunch'], min(2, len(options['lunch']))),
        'dinner': random.sample(options['dinner'], min(2, len(options['dinner']))),
        'snacks': random.sample(options['snacks'], min(3, len(options['snacks'])))
    }
    
    return meal_plan

def generate_dietary_tips(profile, macros, meal_analysis):
    """Generate dietary tips based on user profile and current habits"""
    tips = [
        "Aim to spread your protein intake throughout the day for optimal muscle protein synthesis.",
        "Stay hydrated by drinking at least 8 glasses of water daily.",
        "Include a variety of colorful fruits and vegetables to ensure adequate micronutrient intake."
    ]
    
    # Goal-specific tips
    goal = profile.goal.lower()
    if goal == 'weight_loss':
        tips.extend([
            "Focus on high-volume, low-calorie foods like vegetables to help feel full.",
            "Be mindful of portion sizes and try using smaller plates.",
            "Consider intermittent fasting after consulting with a healthcare professional."
        ])
    elif goal == 'muscle_gain':
        tips.extend([
            "Consume protein within 30 minutes after strength training for optimal recovery.",
            "Don't fear carbohydrates - they're essential for fueling intense workouts.",
            "Consider a slow-digesting protein source like casein before bed."
        ])
    elif goal == 'athletic_performance':
        tips.extend([
            "Consume carbohydrates before workouts to ensure adequate glycogen stores.",
            "Replenish electrolytes during intense or prolonged exercise.",
            "Consider periodizing your nutrition to match your training cycles."
        ])
    
    # Check for potential issues based on meal analysis
    current_protein = meal_analysis['avg_protein']
    target_protein = macros['protein']
    
    if current_protein < (target_protein * 0.8):
        tips.append(f"Your protein intake is significantly below your target of {target_protein}g. Consider adding more protein-rich foods to your diet.")
    
    if meal_analysis['meal_frequency'] < 3:
        tips.append("Consider eating more frequent, smaller meals to help stabilize energy levels throughout the day.")
    
    return tips[:5]  # Return top 5 tips

def analyze_workout_history(workouts):
    """Analyze user's workout history for patterns and frequency"""
    if not workouts:
        return {
            'avg_duration': 0,
            'avg_intensity': 'N/A',
            'workout_frequency': 0,
            'common_exercises': []
        }
    
    # Group by date to find workout frequency
    workout_dates = {}
    intensity_values = {'low': 1, 'medium': 2, 'high': 3}
    
    for workout in workouts:
        date_str = workout.date.strftime('%Y-%m-%d')
        if date_str not in workout_dates:
            workout_dates[date_str] = {
                'duration': 0,
                'intensity_score': 0,
                'exercises': []
            }
        
        workout_dates[date_str]['duration'] += workout.duration or 0
        workout_dates[date_str]['intensity_score'] += intensity_values.get(workout.intensity.lower(), 2)
        workout_dates[date_str]['exercises'].append(workout.exercise_type)
    
    # Calculate averages
    total_days = len(workout_dates)
    if total_days == 0:
        return {
            'avg_duration': 0,
            'avg_intensity': 'N/A',
            'workout_frequency': 0,
            'common_exercises': []
        }
    
    total_duration = sum(day['duration'] for day in workout_dates.values())
    total_intensity_score = sum(day['intensity_score'] for day in workout_dates.values())
    total_exercises = sum(len(day['exercises']) for day in workout_dates.values())
    
    # Convert intensity score back to label
    avg_intensity_score = total_intensity_score / total_exercises if total_exercises > 0 else 2
    intensity_labels = {1: 'low', 2: 'medium', 3: 'high'}
    closest_intensity = min(intensity_labels.keys(), key=lambda k: abs(k - avg_intensity_score))
    
    # Calculate common exercises
    all_exercises = []
    for day in workout_dates.values():
        all_exercises.extend(day['exercises'])
    
    from collections import Counter
    exercise_counter = Counter(all_exercises)
    
    return {
        'avg_duration': round(total_duration / total_days) if total_days > 0 else 0,
        'avg_intensity': intensity_labels.get(closest_intensity, 'medium'),
        'workout_frequency': total_days / 7 if total_days > 0 else 0,  # workouts per week
        'common_exercises': exercise_counter.most_common(5)
    }

def generate_exercise_recommendation(profile, workout_history):
    """Generate personalized exercise recommendations based on user profile and workout history"""
    try:
        # Analyze workout history
        workout_analysis = analyze_workout_history(workout_history)
        
        # Get recommended frequency and duration based on user goal
        goal = profile.goal.lower()
        target_frequency = FREQUENCY_BY_GOAL.get(goal, 3)
        target_duration = DURATION_BY_GOAL.get(goal, 30)
        
        # Generate workout plan
        workout_plan = generate_workout_plan(profile, workout_analysis)
        
        # Create the recommendation object
        recommendation = {
            'target_frequency': target_frequency,
            'target_duration': target_duration,
            'current_stats': {
                'frequency': workout_analysis['workout_frequency'],
                'duration': workout_analysis['avg_duration'],
                'intensity': workout_analysis['avg_intensity']
            },
            'workout_plan': workout_plan,
            'exercise_tips': generate_exercise_tips(profile, workout_analysis)
        }
        
        return recommendation
    except Exception as e:
        logger.error(f"Error generating exercise recommendation: {e}")
        # Return basic recommendation if there's an error
        return {
            'target_frequency': 3,
            'target_duration': 30,
            'current_stats': {'frequency': 0, 'duration': 0, 'intensity': 'N/A'},
            'workout_plan': {'day1': [], 'day2': [], 'day3': []},
            'exercise_tips': [
                "Start slowly and gradually increase intensity and duration.",
                "Always warm up before exercise and cool down afterward.",
                "Consider consulting with a fitness professional for personalized advice."
            ]
        }

def generate_workout_plan(profile, workout_analysis):
    """Generate a simple workout plan based on user preferences and goals"""
    goal = profile.goal.lower()
    
    # Define workout templates by goal
    workout_templates = {
        'weight_loss': {
            'day1': {
                'focus': 'Cardio',
                'exercises': [
                    {'name': 'Brisk Walking or Jogging', 'duration': 30, 'intensity': 'medium'},
                    {'name': 'Jumping Jacks', 'duration': 5, 'intensity': 'high'},
                    {'name': 'Bodyweight Squats', 'sets': 3, 'reps': 15, 'intensity': 'medium'}
                ]
            },
            'day2': {
                'focus': 'HIIT',
                'exercises': [
                    {'name': 'Mountain Climbers', 'duration': 1, 'sets': 4, 'intensity': 'high'},
                    {'name': 'Burpees', 'duration': 1, 'sets': 4, 'intensity': 'high'},
                    {'name': 'High Knees', 'duration': 1, 'sets': 4, 'intensity': 'high'},
                    {'name': 'Rest', 'duration': 1, 'sets': 4, 'intensity': 'low'}
                ]
            },
            'day3': {
                'focus': 'Circuit Training',
                'exercises': [
                    {'name': 'Push-ups', 'sets': 3, 'reps': 10, 'intensity': 'medium'},
                    {'name': 'Lunges', 'sets': 3, 'reps': 12, 'intensity': 'medium'},
                    {'name': 'Plank', 'duration': 30, 'sets': 3, 'intensity': 'medium'},
                    {'name': 'Bicycle Crunches', 'sets': 3, 'reps': 20, 'intensity': 'medium'}
                ]
            },
            'day4': {
                'focus': 'Active Recovery',
                'exercises': [
                    {'name': 'Walking', 'duration': 30, 'intensity': 'low'},
                    {'name': 'Stretching', 'duration': 15, 'intensity': 'low'}
                ]
            },
            'day5': {
                'focus': 'Cardio and Strength',
                'exercises': [
                    {'name': 'Jumping Rope', 'duration': 10, 'intensity': 'high'},
                    {'name': 'Bodyweight Squats', 'sets': 3, 'reps': 15, 'intensity': 'medium'},
                    {'name': 'Push-ups', 'sets': 3, 'reps': 10, 'intensity': 'medium'},
                    {'name': 'Plank', 'duration': 30, 'sets': 3, 'intensity': 'medium'}
                ]
            }
        },
        'muscle_gain': {
            'day1': {
                'focus': 'Upper Body',
                'exercises': [
                    {'name': 'Push-ups', 'sets': 4, 'reps': 12, 'intensity': 'high'},
                    {'name': 'Dumbbell Rows', 'sets': 4, 'reps': 10, 'intensity': 'high'},
                    {'name': 'Shoulder Press', 'sets': 3, 'reps': 10, 'intensity': 'high'},
                    {'name': 'Tricep Dips', 'sets': 3, 'reps': 12, 'intensity': 'high'}
                ]
            },
            'day2': {
                'focus': 'Lower Body',
                'exercises': [
                    {'name': 'Squats', 'sets': 4, 'reps': 12, 'intensity': 'high'},
                    {'name': 'Lunges', 'sets': 3, 'reps': 10, 'intensity': 'high'},
                    {'name': 'Deadlifts', 'sets': 4, 'reps': 8, 'intensity': 'high'},
                    {'name': 'Calf Raises', 'sets': 3, 'reps': 15, 'intensity': 'medium'}
                ]
            },
            'day3': {
                'focus': 'Rest Day',
                'exercises': [
                    {'name': 'Light Stretching', 'duration': 15, 'intensity': 'low'},
                    {'name': 'Foam Rolling', 'duration': 10, 'intensity': 'low'}
                ]
            },
            'day4': {
                'focus': 'Full Body',
                'exercises': [
                    {'name': 'Bench Press', 'sets': 4, 'reps': 8, 'intensity': 'high'},
                    {'name': 'Pull-ups/Lat Pulldowns', 'sets': 3, 'reps': 8, 'intensity': 'high'},
                    {'name': 'Squats', 'sets': 3, 'reps': 10, 'intensity': 'high'},
                    {'name': 'Plank', 'duration': 60, 'sets': 3, 'intensity': 'medium'}
                ]
            }
        },
        'maintenance': {
            'day1': {
                'focus': 'Cardio',
                'exercises': [
                    {'name': 'Jogging or Cycling', 'duration': 20, 'intensity': 'medium'},
                    {'name': 'Bodyweight Circuit', 'duration': 15, 'intensity': 'medium'}
                ]
            },
            'day2': {
                'focus': 'Strength',
                'exercises': [
                    {'name': 'Push-ups', 'sets': 3, 'reps': 10, 'intensity': 'medium'},
                    {'name': 'Squats', 'sets': 3, 'reps': 12, 'intensity': 'medium'},
                    {'name': 'Plank', 'duration': 30, 'sets': 3, 'intensity': 'medium'},
                    {'name': 'Dumbbell Rows', 'sets': 3, 'reps': 10, 'intensity': 'medium'}
                ]
            },
            'day3': {
                'focus': 'Flexibility/Recovery',
                'exercises': [
                    {'name': 'Yoga', 'duration': 30, 'intensity': 'low'},
                    {'name': 'Foam Rolling', 'duration': 10, 'intensity': 'low'}
                ]
            }
        },
        'overall_health': {
            'day1': {
                'focus': 'Cardio',
                'exercises': [
                    {'name': 'Walking or Swimming', 'duration': 30, 'intensity': 'low'},
                    {'name': 'Light Stretching', 'duration': 10, 'intensity': 'low'}
                ]
            },
            'day2': {
                'focus': 'Strength',
                'exercises': [
                    {'name': 'Bodyweight Squats', 'sets': 2, 'reps': 10, 'intensity': 'low'},
                    {'name': 'Modified Push-ups', 'sets': 2, 'reps': 8, 'intensity': 'low'},
                    {'name': 'Chair Dips', 'sets': 2, 'reps': 8, 'intensity': 'low'},
                    {'name': 'Plank', 'duration': 20, 'sets': 2, 'intensity': 'low'}
                ]
            },
            'day3': {
                'focus': 'Flexibility',
                'exercises': [
                    {'name': 'Yoga or Stretching', 'duration': 30, 'intensity': 'low'}
                ]
            }
        },
        'athletic_performance': {
            'day1': {
                'focus': 'Strength and Power',
                'exercises': [
                    {'name': 'Squats', 'sets': 5, 'reps': 5, 'intensity': 'high'},
                    {'name': 'Deadlifts', 'sets': 5, 'reps': 5, 'intensity': 'high'},
                    {'name': 'Box Jumps', 'sets': 4, 'reps': 6, 'intensity': 'high'},
                    {'name': 'Medicine Ball Throws', 'sets': 3, 'reps': 8, 'intensity': 'high'}
                ]
            },
            'day2': {
                'focus': 'Conditioning',
                'exercises': [
                    {'name': 'Sprint Intervals', 'sets': 8, 'distance': '100m', 'intensity': 'high'},
                    {'name': 'Agility Ladder Drills', 'duration': 10, 'intensity': 'high'},
                    {'name': 'Shuttle Runs', 'sets': 5, 'intensity': 'high'}
                ]
            },
            'day3': {
                'focus': 'Active Recovery',
                'exercises': [
                    {'name': 'Light Jogging', 'duration': 20, 'intensity': 'low'},
                    {'name': 'Dynamic Stretching', 'duration': 15, 'intensity': 'low'},
                    {'name': 'Foam Rolling', 'duration': 15, 'intensity': 'low'}
                ]
            },
            'day4': {
                'focus': 'Sport-Specific',
                'exercises': [
                    {'name': 'Sport Drills', 'duration': 30, 'intensity': 'high'},
                    {'name': 'Plyometrics', 'sets': 4, 'reps': 10, 'intensity': 'high'},
                    {'name': 'Core Circuit', 'duration': 15, 'intensity': 'medium'}
                ]
            },
            'day5': {
                'focus': 'Strength and Stability',
                'exercises': [
                    {'name': 'Olympic Lifts', 'sets': 4, 'reps': 5, 'intensity': 'high'},
                    {'name': 'Single-Leg Exercises', 'sets': 3, 'reps': 10, 'intensity': 'medium'},
                    {'name': 'Balance Work', 'duration': 10, 'intensity': 'medium'},
                    {'name': 'Core Work', 'duration': 15, 'intensity': 'high'}
                ]
            }
        }
    }
    
    # Default to maintenance if goal not found
    workout_plan = workout_templates.get(goal, workout_templates['maintenance'])
    
    # Adjust plan based on user's activity level and history
    activity_level = profile.activity_level.lower()
    current_frequency = workout_analysis['workout_frequency']
    
    # For beginners or those with low activity, simplify the plan
    if activity_level in ['sedentary', 'light'] or current_frequency < 1:
        simplified_plan = {}
        for i, (day, workout) in enumerate(list(workout_plan.items())[:3]):
            simplified_plan[f'day{i+1}'] = {
                'focus': workout['focus'],
                'exercises': workout['exercises'][:2]  # Take only first two exercises from each day
            }
        workout_plan = simplified_plan
    
    return workout_plan

def generate_exercise_tips(profile, workout_analysis):
    """Generate exercise tips based on user profile and current habits"""
    tips = [
        "Always warm up before exercise and cool down afterward to prevent injury.",
        "Listen to your body - if something hurts (not just burns), stop and rest.",
        "Consistency is more important than intensity for long-term progress."
    ]
    
    # Goal-specific tips
    goal = profile.goal.lower()
    activity_level = profile.activity_level.lower()
    
    if goal == 'weight_loss':
        tips.extend([
            "Combine strength training with cardio for optimal fat loss.",
            "HIIT (High-Intensity Interval Training) is efficient for burning calories in less time.",
            "Don't rely solely on exercise - nutrition plays a major role in weight loss."
        ])
    elif goal == 'muscle_gain':
        tips.extend([
            "Progressive overload is key - gradually increase weight or reps over time.",
            "Allow 48 hours of rest for muscle groups between strength workouts.",
            "Protein intake timing matters - aim for some protein within 30 minutes post-workout."
        ])
    elif goal == 'athletic_performance':
        tips.extend([
            "Include sport-specific drills that mimic the movements of your activity.",
            "Periodize your training to peak for important events or seasons.",
            "Don't neglect mobility work - it's crucial for performance and injury prevention."
        ])
    
    # Add beginner tips for those with low activity levels
    if activity_level in ['sedentary', 'light']:
        tips.extend([
            "Start slowly - even 10 minutes of activity is better than none.",
            "Walking is an excellent foundation exercise for beginners.",
            "Focus on form before increasing intensity or duration."
        ])
    
    # Add frequency tips based on current workout frequency
    current_frequency = workout_analysis['workout_frequency']
    if current_frequency < 1:
        tips.append("Aim to establish a consistent routine first - try scheduling 2-3 sessions per week at the same time.")
    elif current_frequency > 5:
        tips.append("Make sure you're incorporating enough rest days - overtraining can lead to injury and burnout.")
    
    return tips[:5]  # Return top 5 tips
