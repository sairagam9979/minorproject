"""
Nutrition API Integration Module

This module provides functions to search for food nutrition information
using external nutrition databases.
"""
import os
import logging
import requests
from urllib.parse import urlencode

# Setup logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Nutrition API endpoints and keys
# For this demo, we'll use the Edamam Nutrition API
# In a real application, you would get these from environment variables
NUTRITION_API_ID = os.environ.get("NUTRITION_API_ID", "")
NUTRITION_API_KEY = os.environ.get("NUTRITION_API_KEY", "")
NUTRITION_API_URL = "https://api.edamam.com/api/nutrition-data"

# Fallback sample data in case API is not available
SAMPLE_FOOD_DATA = {
    "apple": {
        "name": "Apple",
        "calories": 95,
        "protein": 0.5,
        "carbs": 25,
        "fat": 0.3,
        "fiber": 4.4
    },
    "banana": {
        "name": "Banana",
        "calories": 105,
        "protein": 1.3,
        "carbs": 27,
        "fat": 0.4,
        "fiber": 3.1
    },
    "chicken breast": {
        "name": "Chicken Breast (100g)",
        "calories": 165,
        "protein": 31,
        "carbs": 0,
        "fat": 3.6,
        "fiber": 0
    },
    "salmon": {
        "name": "Salmon (100g)",
        "calories": 206,
        "protein": 22,
        "carbs": 0,
        "fat": 13,
        "fiber": 0
    },
    "brown rice": {
        "name": "Brown Rice (1 cup cooked)",
        "calories": 216,
        "protein": 5,
        "carbs": 45,
        "fat": 1.8,
        "fiber": 3.5
    },
    "broccoli": {
        "name": "Broccoli (1 cup)",
        "calories": 55,
        "protein": 3.7,
        "carbs": 11,
        "fat": 0.6,
        "fiber": 5.1
    },
    "egg": {
        "name": "Egg (large)",
        "calories": 72,
        "protein": 6.3,
        "carbs": 0.4,
        "fat": 5,
        "fiber": 0
    },
    "greek yogurt": {
        "name": "Greek Yogurt (1 cup)",
        "calories": 130,
        "protein": 22,
        "carbs": 9,
        "fat": 0.7,
        "fiber": 0
    },
    "oatmeal": {
        "name": "Oatmeal (1 cup cooked)",
        "calories": 158,
        "protein": 6,
        "carbs": 27,
        "fat": 3.2,
        "fiber": 4
    },
    "avocado": {
        "name": "Avocado (1/2)",
        "calories": 161,
        "protein": 2,
        "carbs": 8.5,
        "fat": 15,
        "fiber": 6.7
    }
}

def search_food(query, measure=None):
    """
    Search for food nutrition information using the Edamam API.
    If the API call fails, falls back to sample data for certain common foods.
    
    Args:
        query (str): Food item to search for
        measure (str, optional): Measure of the food (e.g., '1 cup', '100g')
    
    Returns:
        dict: Nutrition information for the requested food
    """
    try:
        if not NUTRITION_API_ID or not NUTRITION_API_KEY:
            logger.warning("Nutrition API credentials not found, using sample data")
            return search_sample_data(query)
        
        # Format the query for the API
        ingr = query
        if measure:
            ingr = f"{measure} {query}"
        
        # Prepare API parameters
        params = {
            'app_id': NUTRITION_API_ID,
            'app_key': NUTRITION_API_KEY,
            'ingr': ingr
        }
        
        # Make API request
        response = requests.get(f"{NUTRITION_API_URL}?{urlencode(params)}")
        
        # Check for successful response
        if response.status_code == 200:
            data = response.json()
            
            # Check if food was found
            if data.get('totalWeight', 0) > 0:
                return format_nutrition_data(data, query)
            else:
                logger.warning(f"No nutrition data found for '{query}', using sample data")
                return search_sample_data(query)
        else:
            logger.error(f"API request failed with status {response.status_code}: {response.text}")
            return search_sample_data(query)
    
    except Exception as e:
        logger.exception(f"Error searching for food nutrition data: {e}")
        return search_sample_data(query)

def search_sample_data(query):
    """
    Search for food in the sample data dictionary.
    
    Args:
        query (str): Food item to search for
    
    Returns:
        dict: Sample nutrition data for the food if found, otherwise a generic response
    """
    query_lower = query.lower()
    
    # Check if query matches any key in sample data
    for key, data in SAMPLE_FOOD_DATA.items():
        if key in query_lower or query_lower in key:
            return {
                'found': True,
                'food': data['name'],
                'calories': data['calories'],
                'protein_g': data['protein'],
                'carbs_g': data['carbs'],
                'fat_g': data['fat'],
                'fiber_g': data['fiber']
            }
    
    # Return generic "not found" response
    return {
        'found': False,
        'food': query,
        'message': 'Nutrition data not available for this food'
    }

def format_nutrition_data(api_data, query):
    """
    Format the nutrition data from the API into a standardized format.
    
    Args:
        api_data (dict): Raw API response data
        query (str): Original food query
    
    Returns:
        dict: Formatted nutrition data
    """
    nutrients = api_data.get('totalNutrients', {})
    
    # Extract specific nutrients
    calories = nutrients.get('ENERC_KCAL', {}).get('quantity', 0)
    protein = nutrients.get('PROCNT', {}).get('quantity', 0)
    carbs = nutrients.get('CHOCDF', {}).get('quantity', 0)
    fat = nutrients.get('FAT', {}).get('quantity', 0)
    fiber = nutrients.get('FIBTG', {}).get('quantity', 0)
    
    return {
        'found': True,
        'food': query,
        'weight_g': api_data.get('totalWeight', 0),
        'calories': round(calories, 1),
        'protein_g': round(protein, 1),
        'carbs_g': round(carbs, 1),
        'fat_g': round(fat, 1),
        'fiber_g': round(fiber, 1),
        'full_nutrients': {
            k: {
                'label': v.get('label', ''),
                'quantity': round(v.get('quantity', 0), 2),
                'unit': v.get('unit', '')
            }
            for k, v in nutrients.items()
        }
    }

def get_common_foods():
    """
    Return a list of common foods for suggestions.
    
    Returns:
        list: List of common food names
    """
    return [
        "Apple", "Banana", "Chicken Breast", "Salmon", "Brown Rice",
        "Broccoli", "Egg", "Greek Yogurt", "Oatmeal", "Avocado",
        "Sweet Potato", "Quinoa", "Spinach", "Almonds", "Peanut Butter"
    ]
